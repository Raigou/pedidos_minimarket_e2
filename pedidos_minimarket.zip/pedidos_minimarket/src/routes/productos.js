const { render } = require("ejs");
const express = require("express");
const router = express.Router();
const conn = require("../database");

// /* MOSTRAR TABLA Inventario */
// router.get("/", (req, res) => {
//   conn.query(
//     "SELECT inventario.id_inventario,producto.nombre_producto,cantidad FROM inventario INNER JOIN producto ON inventario.id_inventario = producto.id_inventario;",
//     (err, result) => {
//       if (!err) {
//         res.render("inventario.ejs", {
//           inventario: result,
//         });
//       } else {
//         console.log(err);
//       }
//     }
//   );
// });


/* MOSTRAR TABLA Inventario */
// router.get("/", (req, res) => {
//     conn.query(
//       "SELECT nombre_producto FROM `producto` ;",
//       (err, result) => {
//         if (!err) {
//           res.render("home.ejs", {
//             producto: result,
//           });
//         } else {
//           console.log(err);
//         }
//       }
//     );
//   });
  router.get("/", (req, res) => {
    conn.query(
      "SELECT nombre_producto FROM `producto` ;",
      (err, result) => {
        if (!err) {
          res.render("frutas.ejs", {
            producto: result,
          });
        } else {
          console.log(err);
        }
      }
    );
  });
module.exports = router;
