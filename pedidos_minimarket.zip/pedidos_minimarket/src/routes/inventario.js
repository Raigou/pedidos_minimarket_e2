const { render } = require("ejs");
const express = require("express");
const router = express.Router();
const conn = require("../database");

/* MOSTRAR TABLA Inventario */
router.get("/", (req, res) => {
  conn.query(
    "SELECT inventario.id_inventario,producto.nombre_producto,cantidad FROM inventario INNER JOIN producto ON inventario.id_inventario = producto.id_inventario;",
    (err, result) => {
      if (!err) {
        res.render("inventario.ejs", {
          inventario: result,
        });
      } else {
        console.log(err);
      }
    }
  );
});

router.post("/edit/:id", function (req, res) {
  const { id } = req.params;
  const newA = req.body.cantidad;
  conn.query(
    "UPDATE inventario set cantidad = ? + cantidad WHERE id_inventario=?",[newA[0],id],
    function (err, rs) {
      res.redirect("/");
    }
  );
});

router.post('/add',(req, res) => {
  const {nombre_producto, descuento_producto, precio,tipo,id_inventario} = req.body;
  conn.query('INSERT into producto SET ? ',{
    nombre_producto: nombre_producto,
    descuento_producto: descuento_producto,
      precio: precio,
      tipo: tipo,
      id_inventario: id_inventario
  }, (err, result) => {
      if(!err) {
          res.redirect('/');
      } else {
          console.log(err);
      }
  });
});


module.exports = router;
