const bodyParser = require('body-parser');
const express = require('express');
const path = require('path');

//Inicianilizar
const app = express();
const conn = require('./database');

//configuracion
app.set('port',process.env.PORT || 3000);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'view'));

//Middleware
app.use(express.json());
app.use(bodyParser.urlencoded({extended: true}));

//Rutas
app.use('/',require('./routes/productos'));

//Servidor
app.listen(app.get('port'),() => {
    console.log('Servidor en Puerto',app.get('port'))
});